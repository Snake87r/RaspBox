// JavaScript Document
var NUMDOWNLOAD = 10;
var tmrDownload = "";
var downloadVisible = true;


function downloadFile(id) {
	//invio richiesta avvio download
	$.post("/newDownload", { id: id },  function(data) {
		var jObj = $.parseJSON(JSON.stringify(data));
		if (jObj.message != "")
			alert(jObj.message);
		else {
			if (downloadVisible == true) activeDownloadRefresh(true);
			alert ("Download aggiunto correttamente");
		}
	}, "json");
}


function activeDownloadRefresh(active) {
	downloadVisible = active;
	if (downloadVisible == true) {
		updateDownloadsInfo();
		if (tmrDownload == "")
			tmrDownload = setInterval( function () { updateDownloadsInfo(); }, 1000);
	} else {
		clearInterval(tmrDownload);
		tmrDownload = "";
	}
}

function updateDownloadsInfo() {
	$.post("/updateDownloadsInfo", "", function(data) {
		jObj = $.parseJSON(JSON.stringify(data));
		if (jObj.length > 0) {
			$("#downloads").css('display','block');
			$("#nodownload").css('display','none');
		}
		
		for (i=0; i<NUMDOWNLOAD; i++) {
			idTable = "#dl0" + i;
			if (i < jObj.length) {
				$(idTable).children().attr("id",jObj[i].ID);		
				if (downloadVisible)
				  $(idTable).css('display','block');
				else
					$(idTable).css('display','none');
					
				$(idTable).find("#icon").text(jObj[i].iconState);
				
				// Server Channel Bot Pack
				scbp = jObj[i].server + "&nbsp;&nbsp;" + jObj[i].channel + "&nbsp;&nbsp;" + jObj[i].bot + "&nbsp;&nbsp;" + jObj[i].pack			
				var elemento = $(idTable).find("#scbp");
				fitTextRight(elemento, scbp)
				
				// nome file
				var elemento = $(idTable).find("#file");
				fitTextRight(elemento, jObj[i].file)
				
				// percentule progresso
				$(idTable).find("#barProgress").css("width" , jObj[i].perc + '%');
				$(idTable).find("#percProgress").text(jObj[i].perc + '%');
				
				$(idTable).find("#progSize").html("Scaricati: " + jObj[i].size);
				$(idTable).find("#speed").html("Velocità: " + jObj[i].speed + " /sec");
				$(idTable).find("#time").text("Tempo trascorso: " + jObj[i].time);
				
				var elemento = $(idTable).find("#infoSB");
				fitTextRight(elemento, jObj[i].infoSB);

			} else {
				$(idTable).css('display','none');
			}
		}
		
		if (jObj.length == 0) {
			clearInterval(tmrDownload);
			tmrDownload = "";
			$("#downloads").css('display','none');
			$("#nodownload").css('display','block');
		}
		
	}, "json");
}


function changeStatus(cella) { //invio richiesta di cambio stato download
	idPulsante = $(cella).attr('id');
	idDownload = $(cella).closest('table').attr('id');
	$.post("/updateDownloadStatus", { action: idPulsante, id: idDownload }, null);
}


function fitTextRight(elemento, testo) {
	prefix = "";
	do {
		$(elemento).html(prefix + testo);
		if ( $(elemento)[0].scrollWidth > $(elemento).innerWidth() ) {
			testo = testo.substr(1);
			prefix = "... ";
		}
		else
			break; 
	} while (testo.length > 1);
}
