// IMPORTANT: This are check by other version, change only when you want release!
// IMPORTANT: Update also main.js#version check, latestVersion.js, main.php
var latestVersion='3.2.3b';