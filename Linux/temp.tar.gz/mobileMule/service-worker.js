self.importScripts('latestVersion.js');// Set cache name to mobileMule latestVersion
var CACHE_NAME=latestVersion,urlsToCache=['//ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js','//ajax.googleapis.com/ajax/libs/jquerymobile/1.4.5/jquery.mobile.min.js','//ajax.googleapis.com/ajax/libs/jquerymobile/1.4.5/jquery.mobile.min.css','//ajax.googleapis.com/ajax/libs/jquerymobile/1.4.5/images/ajax-loader.gif','//netdna.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css','//netdna.bootstrapcdn.com/font-awesome/4.3.0/fonts/fontawesome-webfont.woff2?v=4.3.0','./fallback.html','./fallback-icon.png'],urlsToNoCahe=['/collapsible-stats.php','/downloads.php','/downloads-ajax.php','/graph.php','/graph-ajax.php','/listed-stats.php','/log.php','/servers.php','/status.php','/status-ajax.php','/uploads.php','/amule_stats_download.png','/amule_stats_upload.png','/amule_stats_conncount.png',/* Donation package resources */'/config.php','/footer.php','/search-ajax.php','/search.php'];// Resource to cache
// All others (requested resources) will be cached on first request (see 'fetch'
// TODO: Cache also downloads and use form method GET (not cache with query string)
// Add resource to cache
// Delete old cache when rename CACHE_NAME
// Respond with cached and not cached resource
self.addEventListener('install',function(a){a.waitUntil(caches.open(CACHE_NAME).then(function(a){return a.addAll(urlsToCache.map(function(a){return new Request(a,{credentials:'same-origin'})}))}))}),self.addEventListener('activate',function(a){var b=[CACHE_NAME];a.waitUntil(caches.keys().then(function(a){return Promise.all(a.map(function(a){if(!b.includes(a))return caches.delete(a)}))}))}),self.addEventListener('fetch',function(a){// TODO: ignore query string:
// caches.match(event.request, {
//       **ignoreSearch: true**
//     })
a.respondWith(caches.match(a.request).then(function(b){// Cached
return void 0===b?fetch(a.request).then(function(b){// Bad response => Avoid caching
if(!b||200!==b.status||'basic'!==b.type)return b;// Black listed resource => Avoid caching
var c=b.url.split('?')[0].substring(b.url.lastIndexOf('/'));return urlsToNoCahe.includes(c)?b:caches.open(CACHE_NAME).then(function(c){return c.put(a.request,b.clone()),b});// Cache it
}).catch(function(){// No cache and no internet connection
return caches.match('./fallback.html')}):b;// Not cached yet
}))});