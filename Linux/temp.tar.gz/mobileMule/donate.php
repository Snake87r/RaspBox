If you like mobileMule please consider to make a donation
<div style="text-align: center; margin-top: 15px;">

    <a href="https://www.paypal.me/EmanuelePalombo" title="Donate with PayPal" alt="Donate with PayPal"><img src="https://img.shields.io/badge/donate-paypal-green.svg?logo=paypal&style=for-the-badge"></a>
    &nbsp;<br/>
    <a href="https://liberapay.com/Emanuele/donate" title="Donate with Liberapay" alt="Donate with Liberapay"><img
                src="https://img.shields.io/badge/donate-liberapay-green.svg?logo=liberapay&style=for-the-badge"></a>

</div>

<br/>
<strong>note:</strong> Please <strong>uncheck</strong> "paying for good or a service" option on PayPal if you want do a full donation (without fees).<br/>
<br/>

You'll receive <strong>mobileMule Donation Package</strong> with new panels:
<ul>
    <li>Search</li>
    <li>Configurations</li>
    <li>Add ed2k</li>
    <li>MobileMule (allow to change themes, refresh and other stuff)</li>
</ul>

...and you can help and support the development of project.

