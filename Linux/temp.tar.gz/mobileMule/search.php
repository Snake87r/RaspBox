<form action="search-ajax.php" method="post" name="mainform">
<input type="hidden" name="command" value="">

<legend>Filename:</legend>
<input name="searchval" type="text" id="searchval4" size="60">
<input type="submit" value="Search" class="ui-btn-b" data-command="search">

<div data-role="collapsible">
    <h4>Advanced search</h4>

    <div class="ui-grid-c ui-responsive">
        <div class="ui-block-a">
            <div class="ui-body">
                <legend>Availability:</legend>
                <input name="avail" type="text" id="avail13" size="6">
            </div>
        </div>
        <div class="ui-block-b">
            <div class="ui-body">
                <legend>Min Size:</legend>
                <input name="minsize" type="text" id="minsize2" size="5">
                <select name="minsizeu" id="select8" data-native-menu="false">
                    <option value="Byte">Byte</option>
                    <option value="KByte">KByte</option>
                    <option value="MByte" selected>MByte</option>
                    <option value="GByte">GByte</option>
                </select>
            </div>
        </div>
        <div class="ui-block-c">
            <div class="ui-body">
                <legend>Max Size:</legend>
                <input name="maxsize" type="text" id="maxsize4" size="5">
                <select name="maxsizeu" id="select10" data-native-menu="false">
                    <option value="Byte">Byte</option>
                    <option value="KByte">KByte</option>
                    <option value="MByte" selected>MByte</option>
                    <option value="GByte">GByte</option>
                </select>
            </div>
        </div>
        <div class="ui-block-d">
            <div class="ui-body">
                <legend>Search type:</legend>
                <select name="searchtype" id="select" data-native-menu="false">
                    <option value="Local">Local</option>
                    <option value="Global" selected>Global</option>
                    <option value="Kad">Kad</option>
                </select>
            </div>
        </div>
    </div>
</div>

<br/>
<legend>Sort:</legend>
<div class="search-sort" data-role="navbar">
    <ul>
        <li><a href="#" class="ui-btn-active" data-sort-by="sources">Sources</a></li>
        <li><a href="#" data-sort-by="name">File Name</a></li>
        <li><a href="#" data-sort-by="size">Size</a></li>
    </ul>
</div>

<div id="list-search-results" class="ui-content">
    <!-- search results placeholder -->
</div>

<br/>
<button class="ui-btn ui-corner-all" data-command="download" data-notify="Added file(s) to download" style="padding-right: 38px;">Download</button>

<select name="targetcat" id="select32" data-native-menu="false">
    <?php
    $cats = amule_get_categories();
    foreach ($cats as $c) {
        echo "<option value=\"" . $c . "\">", $c, "</option>";
    }
    ?>
</select>
</form>

<div id="list-search-tpl" class="handlebars-template">
    <ul data-role="listview" data-divider-theme="d" data-split-icon="check">
        <li data-role="list-divider">Search results<span class="ui-li-count">{{count}}</span></li>
        {{#each list}}
            <li data-filtertext="{{name}}">
                <a data-hash="{{hash}}" class="file-check">
                    <h3>{{name}}</h3>
                    <p>{{size}}</p>
                    <span class="ui-li-count">{{sources}}</span>
                </a>
                <a id="{{hash}}" data-hash="{{hash}}" class="file-check {{fileCheckClass}}">Select file</a>
            </li>
        {{/each}}
        <li><p>this info is refreshed each <strong>{{refreshList}}</strong> seconds (<a href="#page-mobilemule" class="hash-link">change it</a>)</p></li>
    </ul>
</div>

<script>
    $(document).one('pagecreate', function() {

        var $mainForm = $('form[name="mainform"]');
        var $inputCommand = $('input[name="command"]');
        var $searchResults = $('#list-search-results');

        // AUTO REFRESH SEARCH RESULTS LIST

        getSearchResults();

        if (!!mm.settings.page.search.refreshList) {

            globalTimer = setInterval(function() {

                getSearchResults();

            }, mm.settings.page.search.refreshList);
        }

        $searchResults.on('vclick', '.file-check', function(event) {

            event.stopPropagation();

            var checkboxHashId = $(this).attr('data-hash');
            var $inputHidden = $('input[name="' + checkboxHashId + '"]', $mainForm);

            if (!$inputHidden.length) {

                $('<input>').attr({
                    type: 'hidden',
                    name: checkboxHashId,
                    value: 'on'
                }).appendTo($mainForm);

            } else {
                $inputHidden.remove();
            }

            $('#' + checkboxHashId).toggleClass('ui-btn-active');
        });

        $mainForm.on('submit', function(event) {
            event.preventDefault();
        });

        $('[data-command]').on('vclick', function(event) {

            event.stopPropagation();

            var notifyMsg = $(this).data('notify');
            var command = $(this).data('command');

            if (formCommandSubmit(command)) {
                notifyMsg && notify.message(notifyMsg);
            }
        });

        $('.search-sort a').on('vclick', function(event) {

            event.stopPropagation();

            $('.search-sort a').removeClass('ui-btn-active');
            $(this).addClass('ui-btn-active');

            getSearchResults();
        });

        // UTILS FUNCTIONS

        function formCommandSubmit(command) {
            <?php
                if ($_SESSION["guest_login"] != 0) {
                        echo 'alert("You logged in as guest - commands are disabled");';
                        echo "return;";
                }
            ?>

            $inputCommand.attr('value', command);
            $mainForm.ajaxForm();
            $inputCommand.removeAttr('value');

            return true;
        };

        function getSearchResults() {

            this.listSearch = this.listSearch || $("#list-search-tpl").html();
            this.listSearchHb = this.listSearchHb || Handlebars.compile(this.listSearch);

            var sortBy = $('.search-sort a.ui-btn-active').data('sort-by');

            $.ajax({
                url: 'search-ajax.php',
                data: { command: 'searchresults', sort: sortBy },
                dataType: 'json',
                success: _.bind(function(data) {

                    data.search.refreshList = mm.settings.page.search.refreshList / 1000;
                    var htmlListGenerated = this.listSearchHb(data.search);
                    $searchResults.html(htmlListGenerated);
                }, this)
            });
        };

        Handlebars.registerHelper('fileCheckClass', function() {
            return $('input[name="' + this.hash + '"]', $mainForm).length ? ' ui-btn-active' : '';
        });
    });
</script>

