<form name="mainform" action="" method="post" data-ajax="false">
    <ul data-role="listview" data-inset="true">

        <li data-role="list-divider">Appearance<span class="ui-li-count">1</span></li>
        <li class="ui-field-contain">
            <label for="theme">Theme</label>
            <select id="theme" name="theme">
                <option value="white" data-name="white">White</option>
                <option value="black" data-name="black">Black</option>
                <option value="nativeDroid-dark-blue" data-name="nativeDroid" data-theme="dark" data-color="blue">NativeDroid [dark blue]</option>
                <option value="nativeDroid-dark-green" data-name="nativeDroid" data-theme="dark" data-color="green">NativeDroid [dark green]</option>
                <option value="nativeDroid-dark-purple" data-name="nativeDroid" data-theme="dark" data-color="purple">NativeDroid [dark purple]</option>
                <option value="nativeDroid-dark-red" data-name="nativeDroid" data-theme="dark" data-color="red">NativeDroid [dark red]</option>
                <option value="nativeDroid-dark-yellow" data-name="nativeDroid" data-theme="dark" data-color="yellow">NativeDroid [dark yellow]</option>
                <option value="nativeDroid-light-blue" data-name="nativeDroid" data-theme="light" data-color="blue">NativeDroid [light blue]</option>
                <option value="nativeDroid-light-green" data-name="nativeDroid" data-theme="light" data-color="green">NativeDroid [light green]</option>
                <option value="nativeDroid-light-purple" data-name="nativeDroid" data-theme="light" data-color="purple">NativeDroid [light purple]</option>
                <option value="nativeDroid-light-red" data-name="nativeDroid" data-theme="light" data-color="red">NativeDroid [light red]</option>
                <option value="nativeDroid-light-yellow" data-name="nativeDroid" data-theme="light" data-color="yellow">NativeDroid [light yellow]</option>
                <option value="nativeDroid2-no-color" data-name="nativeDroid2" data-color="no-color">NativeDroid2</option>
                <option value="nativeDroid2-blue" data-name="nativeDroid2" data-color="blue">NativeDroid2 [blue]</option>
                <option value="nativeDroid2-grey" data-name="nativeDroid2" data-color="grey">NativeDroid2 [grey]</option>
                <option value="nativeDroid2-indigo" data-name="nativeDroid2" data-color="indigo">NativeDroid2 [indigo]</option>
                <option value="nativeDroid2-red" data-name="nativeDroid2" data-color="red">NativeDroid2 [red]</option>
                <option value="nativeDroid2-yellow" data-name="nativeDroid2" data-color="yellow">NativeDroid2 [yellow]</option>
            </select>
            <label for="main-hash">Initial page</label>
            <select id="main-hash" name="main-hash">
                <option value="#page-status">Status</option>
                <option value="#page-downloads">Downloads</option>
                <option value="#page-uploads">Uploads</option>
                <option value="#page-search">Search</option>
                <option value="#page-config">Settings</option>
                <option value="#page-mobilemule">MobileMule</option>
                <option value="#page-servers">Servers</option>
                <option value="#page-listed-stats">Statistics</option>
                <option value="#page-graph">Graphs</option>
                <option value="#page-log">Log</option>
                <option value="#page-footer">Add ed2k</option>
            </select>
        </li>
        <li data-role="list-divider">Behaviour<span class="ui-li-count">6</span></li>
        <li class="ui-field-contain">
            <label for="check-latest-version">Check new version on start</label>
            <input type="checkbox" data-role="flipswitch" name="check-latest-version" id="check-latest-version">
        </li>
        <li class="ui-field-contain">
            <label for="notifyDelay">Notifications delay</label>
            <input type="range" name="notifyDelay" id="notifyDelay" value="6" min="0" max="20" step="1">
        </li>
        <li class="ui-field-contain">
            <label for="refresh-status-page">Status page refresh</label>
            <input type="range" name="refresh-status-page" id="refresh-status-page" value="3" min="0" max="10" step="0.25">
        </li>
        <li class="ui-field-contain">
            <label for="tickChart-status-page">Status page tick chart</label>
            <input type="range" name="tickChart-status-page" id="tickChart-status-page" value="10" min="5" max="100" step="1">
        </li>
        <li class="ui-field-contain">
            <label for="refreshList-downloads-page">Downloads page refresh</label>
            <input type="range" name="refreshList-downloads-page" id="refreshList-downloads-page" value="3" min="0" max="10" step="0.25">
        </li>
        <li class="ui-field-contain">
            <label for="refreshList-search-page">Search page refresh</label>
            <input type="range" name="refreshList-search-page" id="refreshList-search-page" value="4" min="0" max="20" step="1">
        </li>
        <li class="ui-field-contain">
            <label for="refresh-graph-page">Graph page refresh</label>
            <input type="range" name="refresh-graph-page" id="refresh-graph-page" value="3" min="0" max="20" step="0.50">
        </li>
        <li><p>this settings is only for this client/browser.</p></li>
    </ul>
</form>

<script>
    $(document).one('pagecreate', function () {

        // INIT VALUE

        var $selectTheme = $('select#theme');
        var $mainHash = $('select#main-hash');
        var $checkLatestVersion = $('input#check-latest-version');
        var $notifyDelay = $('input#notifyDelay');
        var $refreshStatusPage = $('input#refresh-status-page');
        var $tickChartStatusPage = $('input#tickChart-status-page');
        var $refreshListDownloadsPage = $('input#refreshList-downloads-page');
        var $refreshListSearchPage = $('input#refreshList-search-page');
        var $refreshGraphPage = $('input#refresh-graph-page');

        // Init settings with stored (or default) values
        $selectTheme.val(mm.settings.theme.optionValue).selectmenu('refresh');
        $mainHash.val(mm.settings.mainHash).selectmenu('refresh');
        $checkLatestVersion.prop('checked', mm.settings.checkLatestVersion).flipswitch('refresh');
        $notifyDelay.val(mm.settings.notifyDelay/1000).slider('refresh');
        $refreshStatusPage.val(mm.settings.page.status.refresh/1000).slider('refresh');
        $tickChartStatusPage.val(mm.settings.page.status.tickChart).slider('refresh');
        $refreshListDownloadsPage.val(mm.settings.page.downloads.refreshList/1000).slider('refresh');
        $refreshListSearchPage.val(mm.settings.page.search.refreshList/1000).slider('refresh');
        $refreshGraphPage.val(mm.settings.page.graph.refresh/1000).slider('refresh');

        // EVENTS HANDLING

        $selectTheme.change(function () {

            var data = $(this).find(':selected').data();

            mm.localStorage.set('theme', $.extend({
                optionValue: $(this).val()
            }, data));

            location.reload();
        });

        $mainHash.on("change", function() {
            mm.settings.mainHash = $(this).val();
            mm.localStorage.set('main-hash', mm.settings.mainHash);
        });

        $checkLatestVersion.on("change", function() {
            mm.settings.checkLatestVersion = $(this).is(':checked');
            mm.localStorage.set('check-latest-version', mm.settings.checkLatestVersion);
        });

        $notifyDelay.on("change", function() {
            mm.settings.notifyDelay = $(this).val()*1000;
            mm.localStorage.set('notifyDelay', mm.settings.notifyDelay);
        });

        $refreshStatusPage.on("change", function() {
            mm.settings.page.status.refresh = $(this).val()*1000;
            mm.localStorage.set('page-status-refresh', mm.settings.page.status.refresh);
        });

        $tickChartStatusPage.on("change", function() {
            mm.settings.page.status.tickChart = $(this).val();
            mm.localStorage.set('page-status-tickChart', mm.settings.page.status.tickChart);
        });

        $refreshListDownloadsPage.on("change", function() {
            mm.settings.page.downloads.refreshList = $(this).val()*1000;
            mm.localStorage.set('page-downloads-refreshList', mm.settings.page.downloads.refreshList);
        });

        $refreshListSearchPage.on("change", function() {
            mm.settings.page.search.refreshList = $(this).val()*1000;
            mm.localStorage.set('page-search-refreshList', mm.settings.page.search.refreshList);
        });

        $refreshGraphPage.on("change", function() {
            mm.settings.page.graph.refresh = $(this).val()*1000;
            mm.localStorage.set('page-graph-refresh', mm.settings.page.graph.refresh);
        });
    });
</script>

