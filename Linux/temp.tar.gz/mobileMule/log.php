<div data-role="collapsible" data-collapsed="false">
    <h3>Log</h3>

    <p style="white-space: pre-line;"><small><?php echo amule_get_log(0); ?></small></p>
</div>
<div data-role="collapsible">
    <h3>Server info</h3>

    <p style="white-space: pre-line;"><small><?php echo amule_get_serverinfo(0); ?><small></p>
</div>

